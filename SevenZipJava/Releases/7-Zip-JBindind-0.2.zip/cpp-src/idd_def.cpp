#define INITGUID
#include <initguid.h>

#include "StdAfx.h"

#include "CLSIDs.h"



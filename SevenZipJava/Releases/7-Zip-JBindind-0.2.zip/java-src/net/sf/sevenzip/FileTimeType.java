package net.sf.sevenzip;

public enum FileTimeType {
	WINDOWS, UNIX, DOS
}

/**
 * 
 */
package net.sf.sevenzip;

public enum ArchiveFormat {
	ARJ, SEVEN_ZIP, BZIP_2, CAB, CHM, CPIO, CDEB, GZIP, //
	ISO, LZH, NSIS, RAR, RPM, SPLIT, TAR, Z, ZIP
}
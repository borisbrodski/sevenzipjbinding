package net.sf.sevenzip;

public interface ICryptoGetTextPassword {
	public String cryptoGetTextPassword() throws SevenZipException;
}

package net.sf.sevenzip;

/**
 * 
 * Enumeration of possible operation results by update operations.
 * 
 * @author Boris Brodski
 * @version 1.0
 */
public enum UpdateOperationResult {
	OK, //
	ERROR
}

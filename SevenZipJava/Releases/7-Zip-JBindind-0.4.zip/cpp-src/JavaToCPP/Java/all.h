#ifndef ALL_H_
#define ALL_H_

#include "net_sf_sevenzip_impl_InArchiveImpl.h"
#include "net_sf_sevenzip_SevenZip.h"

#endif /*ALL_H_*/

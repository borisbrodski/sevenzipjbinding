//============================================================================
// Name        : SevenZipBinding.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "7zip.h"

using namespace std;
#define DLLFILENAME "7z.dll"

typedef UINT32 (WINAPI * CreateObjectFunc)(
		const GUID *clsID,
		const GUID *interfaceID,
		void **outObject);

// {23170F69-40C1-278A-1000-000110070000}
DEFINE_GUID(CLSID_CFormat7z, 0x23170F69, 0x40C1, 0x278A, 0x10, 0x00, 0x00,
		0x01, 0x10, 0x07, 0x00, 0x00);

int main() {

	HINSTANCE lib = LoadLibraryA(DLLFILENAME);

	if (NULL == lib) {
		cout << "Error loading dll: " << DLLFILENAME;
		return 1;
	}

	CreateObjectFunc createObjectFunc = (CreateObjectFunc)GetProcAddress(lib,
			"CreateObject");

	if (NULL == createObjectFunc) {
		cout << "CreateObject returns null";
		return 1;
	}

	CMyComPtr<IInArchive> archive;

	if (createObjectFunc(&CLSID_CFormat7z, &IID_IInArchive, (void **)&archive)
			!= S_OK) {
		printf("Can not get class object");
		return 1;
	}

	cout << "Successfull!";

	CInFileStream *fileSpec = new CInFileStream;
	CMyComPtr<IInStream> file = fileSpec;

	if (!fileSpec->Open("test.7z") {
		printf("Can not open");
		return 1;
	}
	if (archive->Open(file, 0, 0) != S_OK)
		return 0;

	return 0;
}

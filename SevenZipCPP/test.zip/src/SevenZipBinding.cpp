//============================================================================
// Name        : SevenZipBinding.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "StdAfx.h"

#include <initguid.h>

#include "Common/StringConvert.h"
#include "7zip/Common/FileStreams.h"
#include "7zip/Archive/IArchive.h"
#include "Windows/PropVariant.h"
#include "Windows/PropVariantConversions.h"
#include "Windows/DLL.h"

using namespace std;
#define DLLFILENAME "7z.dll"

bool g_IsNT = false;

typedef UINT32 (WINAPI * CreateObjectFunc)(const GUID *clsID,
		const GUID *interfaceID, void **outObject);

// {23170F69-40C1-278A-1000-000110070000}
DEFINE_GUID(CLSID_CFormat7z, 0x23170F69, 0x40C1, 0x278A, 0x10, 0x00, 0x00,
		0x01, 0x10, 0x07, 0x00, 0x00);

int main() {

	HINSTANCE lib = LoadLibraryA(DLLFILENAME);

	if (NULL == lib) {
		printf("Error loading dll %s", DLLFILENAME);
		return 1;
	}

	CreateObjectFunc createObjectFunc = (CreateObjectFunc)GetProcAddress(lib,
			"CreateObject");

	if (NULL == createObjectFunc) {
		printf("CreateObject returns null");
		return 1;
	}

	CMyComPtr<IInArchive> archive;

	if (createObjectFunc(&CLSID_CFormat7z, &IID_IInArchive, (void **)&archive)
			!= S_OK) {
		printf("Can not get class object");
		return 1;
	}

	printf("Successfull!\n\n");

	CInFileStream *fileSpec = new CInFileStream;
	CMyComPtr<IInStream> file = fileSpec;

	if (!fileSpec->Open("test.zip")) {
		printf("Can not open archive file\n");
		return 1;
	}
	if (archive->Open(file, 0, 0) != S_OK) {
		printf("Problems...");
		return 0;
	}

	UInt32 numItems = 0;
	archive->GetNumberOfItems(&numItems);
	printf("Count of items: %i\n", numItems);
	for (UInt32 i = 0; i < numItems; i++) {
		NWindows::NCOM::CPropVariant propVariant;
		archive->GetProperty(i, kpidPath, &propVariant);
		UString s = ConvertPropVariantToString(propVariant);
		printf("%s\n", (LPCSTR)GetOemString(s));
	}

	return 0;
}
